create database BrickBreaker;

use BrickBreaker;
 
 DROP VIEW IF EXISTS leaderboard;
 
show tables;


 CREATE TABLE  IF NOT EXISTS players (
    player_id VARCHAR(50) PRIMARY KEY,
    player_name VARCHAR(100),
    registration_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
); 

desc  players;
 SELECT * FROM players;


 CREATE TABLE  IF NOT EXISTS game_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    player_id VARCHAR(50),
    player_name VARCHAR(100),
    score INT,
    session_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (player_id) REFERENCES players(player_id)
);
desc  game_sessions;

select * from game_sessions;
 
 CREATE  VIEW    leaderboard AS
SELECT player_id, player_name, MAX(score) AS high_score
FROM game_sessions
GROUP BY player_id, player_name
ORDER BY high_score DESC;

 select * from leaderboard;
 
desc  leaderboard;

CREATE TABLE  IF NOT EXISTS achievements (
    achievement_id INT AUTO_INCREMENT PRIMARY KEY,
    player_id VARCHAR(50),
    title VARCHAR(100),
    description TEXT,
    awarded_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (player_id) REFERENCES players(player_id)
);

select * from achievements;
 desc achievements;