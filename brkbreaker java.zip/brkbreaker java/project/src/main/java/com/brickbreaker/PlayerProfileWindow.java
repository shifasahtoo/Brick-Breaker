 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.brickbreaker;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PlayerProfileWindow extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/BrickBreaker";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    public PlayerProfileWindow(String playerId) {
        setTitle("Player Profile");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.BLACK);
        setLayout(new GridLayout(3, 1, 10, 10));

        JLabel nameLabel = new JLabel();
        JLabel totalScoreLabel = new JLabel();
        JLabel sessionsLabel = new JLabel();

        JLabel[] labels = {nameLabel, totalScoreLabel, sessionsLabel};
        for (JLabel label : labels) {
            label.setForeground(Color.CYAN);
            label.setFont(new Font("Consolas", Font.PLAIN, 18));
            add(label);
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT player_name, SUM(score) AS total, COUNT(*) AS sessions FROM game_sessions WHERE player_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, playerId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    nameLabel.setText("Player: " + rs.getString("player_name"));
                    totalScoreLabel.setText("Total Score: " + rs.getInt("total"));
                    sessionsLabel.setText("Sessions Played: " + rs.getInt("sessions"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        setVisible(true);
    }
}

