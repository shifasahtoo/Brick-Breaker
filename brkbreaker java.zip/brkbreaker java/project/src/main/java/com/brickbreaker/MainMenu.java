/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package com.brickbreaker;

import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    public MainMenu(GameFrame gameFrame) {
        setTitle("Main Menu");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.BLACK);
        setLayout(new GridLayout(5, 1, 10, 10));

        Font font = new Font("Consolas", Font.BOLD, 14);

        JButton playButton = new JButton(" Play Game");
        JButton leaderboardButton = new JButton(" View Leaderboard");
        JButton exitButton = new JButton(" Exit");

        JButton[] buttons = {playButton, leaderboardButton,  exitButton};

        for (JButton btn : buttons) {
            btn.setFont(font);
            btn.setBackground(Color.DARK_GRAY);
            btn.setForeground(Color.white);
            add(btn);
        }

        playButton.addActionListener(e -> {
            gameFrame.setVisible(true);
            dispose(); // close menu
        });

        leaderboardButton.addActionListener(e -> new LeaderboardWindow());
      
        exitButton.addActionListener(e -> System.exit(0));

        setVisible(true);
    }
}

 

