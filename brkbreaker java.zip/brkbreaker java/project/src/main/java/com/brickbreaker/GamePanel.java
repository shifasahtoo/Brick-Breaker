package com.brickbreaker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private boolean playing = false;
    private int score = 0;
    private int lives = 3;
    private int level = 1;

    private Timer timer;
    private Paddle paddle;
    private Ball ball;
    private Brick[][] bricks;
    private GameFrame gameFrame;

    private static final int PANEL_WIDTH = 800;
    private static final int PANEL_HEIGHT = 600;

    // 🟨 Border Settings
    private static final int BORDER_X = 40;
    private static final int BORDER_Y = 60;
    private static final int BORDER_WIDTH = PANEL_WIDTH - 2 * BORDER_X;
    private static final int BORDER_HEIGHT = PANEL_HEIGHT - BORDER_Y - 40;

    private int brickRows = 3;
    private int brickCols = 6;

    private static final Color[] BRICK_COLORS = {
        Color.RED, Color.ORANGE, Color.GREEN, Color.BLUE, Color.YELLOW
    };

    public GamePanel(GameFrame frame) {
        this.gameFrame = frame;
        setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);

        initializeGame();
        timer = new Timer(10, this);
    }

    private void initializeGame() {
        paddle = new Paddle(PANEL_WIDTH / 2 - 50, PANEL_HEIGHT - 70, BORDER_X, BORDER_X + BORDER_WIDTH);
        ball = new Ball(PANEL_WIDTH / 2, PANEL_HEIGHT - 90);
        updateLevelSettings();
        playing = false;
        lives = 3;
        score = 0;
    }

    private void updateLevelSettings() {
        brickRows = 3 + level - 1;
        brickCols = 6;
        initializeBricks();

        double speed = 2.5 + level * 0.5;
        ball.setSpeed(speed, -speed);
    }

    private void initializeBricks() {
        bricks = new Brick[brickRows][brickCols];
        int startX = BORDER_X + 10;
        int startY = BORDER_Y + 30;

        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                Color color = BRICK_COLORS[row % BRICK_COLORS.length];
                int x = startX + col * (Brick.WIDTH + 10);
                int y = startY + row * (Brick.HEIGHT + 10);
                bricks[row][col] = new Brick(x, y, color);
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 🟨 Draw Yellow Border
        g2d.setColor(Color.YELLOW);
        g2d.drawRect(BORDER_X, BORDER_Y, BORDER_WIDTH, BORDER_HEIGHT);

        // 🎮 Draw Game Elements
        paddle.draw(g2d);
        ball.draw(g2d);

        for (int row = 0; row < bricks.length; row++) {
            for (int col = 0; col < bricks[row].length; col++) {
                if (bricks[row][col] != null) {
                    bricks[row][col].draw(g2d);
                }
            }
        }

        // 💬 Draw Score, Lives, Level (outside border)
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));
        g2d.drawString("Score: " + score, 10, 25);
        g2d.drawString("Lives: " + lives, PANEL_WIDTH - 100, 25);
        g2d.drawString("Level: " + level, PANEL_WIDTH / 2 - 30, 25);

        if (!playing && lives > 0) {
            g2d.setFont(new Font("Arial", Font.BOLD, 28));
            g2d.drawString("Press SPACE to Start", PANEL_WIDTH / 2 - 140, PANEL_HEIGHT / 2);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (playing) {
            ball.move();
            checkCollisions();
        }
        repaint();
    }

    private void checkCollisions() {
        Rectangle bounds = ball.getBounds();

        // ⛔ Bounce off yellow border
        if (ball.getX() <= BORDER_X || ball.getX() >= BORDER_X + BORDER_WIDTH - Ball.SIZE) {
            ball.reverseX();
        }
        if (ball.getY() <= BORDER_Y) {
            ball.reverseY();
        }

        // ⛔ Lose life if ball hits bottom of border
        if (ball.getY() >= BORDER_Y + BORDER_HEIGHT - Ball.SIZE) {
            lives--;
            if (lives <= 0) {
                gameOver();
            } else {
                resetBall();
            }
        }

        // ⛳ Bounce on paddle
        if (bounds.intersects(paddle.getBounds())) {
            ball.reverseY();
            double relative = (ball.getX() - paddle.getX()) / Paddle.WIDTH;
            ball.setXSpeed((relative - 0.5) * 6);
        }

        // 💥 Collision with bricks
        for (int row = 0; row < bricks.length; row++) {
            for (int col = 0; col < bricks[row].length; col++) {
                if (bricks[row][col] != null && bounds.intersects(bricks[row][col].getBounds())) {
                    bricks[row][col] = null;
                    ball.reverseY();
                    score += 10;
                    Toolkit.getDefaultToolkit().beep(); // 🔔 Beep sound
                    checkWin();
                }
            }
        }
    }

    private void checkWin() {
        for (int row = 0; row < bricks.length; row++) {
            for (int col = 0; col < bricks[row].length; col++) {
                if (bricks[row][col] != null) {
                    return;
                }
            }
        }
        nextLevel();
    }

   private void nextLevel() {
    if (level == 3) {
        playing = false;
        timer.stop();
        JOptionPane.showMessageDialog(this, "🎉 Congratulations! You completed all levels!");
        gameFrame.saveScore(score);
        int choice = JOptionPane.showConfirmDialog(this,
                "Final Score: " + score + "\nDo you want to play again?",
                "You Won!", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            level = 1;
            initializeGame();
            timer.start();
        } else {
            System.exit(0);
        }
    } else {
        level++;
        playing = false;
        updateLevelSettings();
        resetBall();

        JOptionPane.showMessageDialog(this, "Level " + (level - 1) + " Complete!\nGet ready for Level " + level);
        timer.start();
    }
}

    private void gameOver() {
    playing = false;
    timer.stop();
    gameFrame.saveScore(score);

    // 🏆 Achievement unlock check
   if (score >= 100) {
    gameFrame.unlockAchievement("Score Master", "You scored over 100 points!");
}
 

    int choice = JOptionPane.showConfirmDialog(this,
            "Game Over! Final Score: " + score + "\nPlay Again?", "Game Over", JOptionPane.YES_NO_OPTION);
    if (choice == JOptionPane.YES_OPTION) {
        level = 1;
        initializeGame();
        timer.start();
    } else {
        System.exit(0);
    }
}


    private void resetBall() {
        playing = false;
        ball.reset(paddle.getX() + Paddle.WIDTH / 2, PANEL_HEIGHT - 90);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                paddle.moveLeft();
                if (!playing) {
                    ball.setX(paddle.getX() + Paddle.WIDTH / 2);
                }
                break;
            case KeyEvent.VK_RIGHT:
                paddle.moveRight();
                if (!playing) {
                    ball.setX(paddle.getX() + Paddle.WIDTH / 2);
                }
                break;
            case KeyEvent.VK_SPACE:
                if (!playing) {
                    playing = true;
                    timer.start();
                }
                break;
        }
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}
