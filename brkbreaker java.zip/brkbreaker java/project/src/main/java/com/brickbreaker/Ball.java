package com.brickbreaker;

import java.awt.*;
import java.awt.geom.*;

public class Ball {
    public static final int SIZE = 10;
    private double x, y;
    private double xSpeed = 3;
    private double ySpeed = -3;

    public Ball(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void move() {
        x += xSpeed;
        y += ySpeed;
    }

    public void draw(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fill(new Ellipse2D.Double(x - SIZE/2, y - SIZE/2, SIZE, SIZE));
    }

    public void reverseX() {
        xSpeed = -xSpeed;
    }

    public void reverseY() {
        ySpeed = -ySpeed;
    }

    public void setXSpeed(double speed) {
        xSpeed = speed;
    }

    public void reset(int x, int y) {
        this.x = x;
        this.y = y;
        xSpeed = 3;
        ySpeed = -3;
    }

    public void setSpeed(double xSpeed, double ySpeed) {
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }

    public Rectangle getBounds() {
        return new Rectangle((int)(x - SIZE/2), (int)(y - SIZE/2), SIZE, SIZE);
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public void setX(double x) { this.x = x; }
}
