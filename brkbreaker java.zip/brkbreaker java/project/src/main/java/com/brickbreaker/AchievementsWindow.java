/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

   package com.brickbreaker;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AchievementsWindow extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/BrickBreaker";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    public AchievementsWindow(String playerId) {
        setTitle("My Achievements");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columns = {"Title", "Description", "Time"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT title, description, awarded_time FROM achievements WHERE player_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, playerId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getString("title"),
                            rs.getString("description"),
                            rs.getTimestamp("awarded_time")
                    });
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);
        getContentPane().setBackground(Color.BLACK);
        setVisible(true);
    }

    private void styleTable(JTable table) {
        table.setBackground(Color.BLACK);
        table.setForeground(Color.CYAN);
        table.setFont(new Font("Consolas", Font.PLAIN, 14));
        table.setRowHeight(30);

        table.getTableHeader().setBackground(Color.DARK_GRAY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Consolas", Font.BOLD, 14));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center);
        }
    }
}

