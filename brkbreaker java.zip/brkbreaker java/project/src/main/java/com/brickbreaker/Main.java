package com.brickbreaker;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
         GameFrame gameFrame = new GameFrame();
gameFrame.setVisible(false); // Hide initially
new MainMenu(gameFrame);

        });
    }
}
