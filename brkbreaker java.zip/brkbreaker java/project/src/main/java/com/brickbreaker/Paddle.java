package com.brickbreaker;

import java.awt.*;

public class Paddle {
    public static final int WIDTH = 100;
    public static final int HEIGHT = 10;
    private int borderLeft = 40;
    private int borderRight = 760; // 800 - 40

    private int x;
    private int y;
    private int speed = 20;

    public Paddle(int x, int y, int borderLeft, int borderRight) {
    this.x = x;
    this.y = y;
    this.borderLeft = borderLeft;
    this.borderRight = borderRight;
}


    public void draw(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fillRect(x, y, WIDTH, HEIGHT);
    }

    public void moveLeft() {
    if (x - speed >= borderLeft) {
        x -= speed;
    } else {
        x = borderLeft;
    }
}

public void moveRight() {
    if (x + WIDTH + speed <= borderRight) {
        x += speed;
    } else {
        x = borderRight - WIDTH;
    }
}


    public Rectangle getBounds() {
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }

    public int getX() { return x; }
    public int getY() { return y; }
}