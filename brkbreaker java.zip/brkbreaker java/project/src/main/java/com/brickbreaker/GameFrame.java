package com.brickbreaker;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.sound.sampled.*;

public class GameFrame extends JFrame {
    private String playerName;
    private String playerId;
    private GamePanel gamePanel;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/brickbreaker"; // use correct lowercase db name
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    public GameFrame() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading MySQL driver: " + e.getMessage());
            System.exit(1);
        }

        showLoginDialog();
        initializeFrame();
    }

    private void showLoginDialog() {
        JDialog dialog = new JDialog(this, "Welcome to Brick Breaker Game", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBackground(Color.BLACK);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel nameLabel = new JLabel("Enter your name:");
        nameLabel.setForeground(Color.WHITE);
        JTextField nameField = new JTextField();
        nameField.setBackground(Color.DARK_GRAY);
        nameField.setForeground(Color.WHITE);

        JLabel idLabel = new JLabel("Enter your ID:");
        idLabel.setForeground(Color.WHITE);
        JTextField idField = new JTextField();
        idField.setBackground(Color.DARK_GRAY);
        idField.setForeground(Color.WHITE);

        JButton startButton = new JButton("Start Game");
        startButton.setFocusPainted(false);

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(idLabel);
        panel.add(idField);
        panel.add(startButton);

        dialog.add(panel, BorderLayout.CENTER);

        startButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String id = idField.getText().trim();

            if (name.isEmpty() || id.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Name and ID can't be empty!");
            } else {
                playerName = name;
                playerId = id;
                registerPlayerIfNotExists();
                dialog.dispose(); // close dialog
            }
        });

        dialog.setVisible(true);

        if (playerName == null || playerId == null) {
            System.exit(0); // if dialog closed without input
        }
    }

    private void initializeFrame() {
        setTitle("Brick Breaker - Player: " + playerName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        gamePanel = new GamePanel(this);
        add(gamePanel);
        pack();
        setLocationRelativeTo(null);
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Options");

       JMenuItem leaderboardItem = new JMenuItem("View Leaderboard");
        leaderboardItem.addActionListener(e -> new LeaderboardWindow());

       JMenuItem achievementsItem = new JMenuItem("My Achievements");
       achievementsItem.addActionListener(e -> new AchievementsWindow(playerId));

       menu.add(leaderboardItem);
       menu.add(achievementsItem);
       menuBar.add(menu);
       setJMenuBar(menuBar);

    }

    private void registerPlayerIfNotExists() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT IGNORE INTO players (player_id, player_name) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, playerId);
                pstmt.setString(2, playerName);
                pstmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error registering player: " + e.getMessage());
        }
    }

    public void saveScore(int score) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO game_sessions (player_id, player_name, score) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, playerId);
                pstmt.setString(2, playerName);
                pstmt.setInt(3, score);
                pstmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving score: " + e.getMessage());
        }
    }

   public void unlockAchievement(String title, String description) {
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        String sql = "INSERT INTO achievements (player_id, title, description) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, playerId);
            pstmt.setString(2, title);
            pstmt.setString(3, description);
            pstmt.executeUpdate();
            playSound("resources/achievement.wav");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

private void playSound(String soundFile) {
    try {
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(new java.io.File(soundFile));
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);
        clip.start();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    String getPlayerId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
